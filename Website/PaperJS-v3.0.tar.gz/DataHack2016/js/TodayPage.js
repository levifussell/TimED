//class called person with an empty constructor
var Person = function(FirstName) {
    
    this.firstName = FirstName;
    
    console.log("person created");
};

/*//define class methods
Person.prototype.sayHello = function(){
    console.log('hello i am' + this.firstName);  
};

//------------------------
//Student class child of person
function Student(firstName, subject){
    
    //Call the parent constructor
    Person.call(this, firstName);
    //initialise student-specific variables
    this.subject = subject;  
};

//Methods
Student.prototype = Object.create(Person.prototype); //see note below

//set constructor property to refer to student
Student.prototype.constructor = Student;

//replace say hello method
Student.prototype.sayHello = function(){
    console.log('student' + this.firstName + this.subject);  
};

//---------------------TEST
//new instances of Person
var person1 = new Person('joe');
var person2 = new Person('bob');

person1.sayHello();

var student1 = new Student('jim', 'cars');
student1.sayHello();*/



//PAGE: use for different actions
//-------------------------------

//Construct
var Page = function(Name){
    
    this.name = Name
};

//Methods----------
    
    //add object to page
Page.prototype.addObject = function(obj) {
    
    this.objects.push(obj)
};
//-------------------------------

//LECTURE OBJ-------------------
//------------------------------

//SLIDE OBJ-------------------
/*var SlideObj = function(Name, Position){
    
    this.name = Name;

    this.rec = new Path.Circle(new Point(200, 200), 100);
    this.rec.fillColor = 'green';
    this.rec.onMouseDrag = function(event) {
        this.rec.position.x += event.delta.x;
    }
};
*/
/*function SlideObj(Name, Position){
    
    //Call the parent constructor
    Item.call(this);
    //initialise student-specific variables
    this.name = Name;  
    this.rec = new Path.Circle(Position);
    this.rec.fillColor = 'green';
};*/



//------------------------------

//PAGE CREATES
//--------------------
CreatePageToday();
//project.activeLayer.removeChildren();

//Create Today Page:
function CreatePageToday(){
 
    var path = new Path.Circle({
                    center: new Point(10, 10),
                    radius: 50,
                    fillColor: 'red'
                });
    path.onMouseDrag = function(event) {
        path.position.x += event.delta.x;
    };
    
    //slide dates
    SlideObj(new Point(200, 200), ["Monday", "3 March"]);
}

//Position = point, Names = array of texts, header is Names[0]
function SlideObj(Position, Names) {
    //create a group to add items to
    var slideObjGroup = new Group();
    //add mouse input on group
    slideObjGroup.onMouseDrag = function(event) {
        slideObjGroup.position.x += event.delta.x;
    }
    /*slideObjGroup.on('frame', function() {
       this.position.x += 1; 
    });*/
    //border
    /*var rec = new Rectangle(
                Position, new Point(100, 100));
    rec.center = Position;
    var bound = new Path.Rectangle(rec);
    bound.fillColor = 'red';
    slideObjGroup.addChild(bound);*/
    
    for(var i = 0; i < Names.length; ++i){
        //text
        var text = new PointText({
            point: Position + [0, i * 15],
            content: Names[i],
            fillColor: 'white',
            fontFamily: 'monospace',
            fontWeight: i == 0? 'bold':'normal',
            fontSize: i == 0? 20 : 10,
            justification: 'center'
        });
        
        //add to group
        slideObjGroup.addChild(text);
    }
}