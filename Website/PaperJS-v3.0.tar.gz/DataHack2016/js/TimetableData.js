//Asyncronous
    GetClassLectures(['INFR08019_SV1_SEM1', 'INFR08008_SV1_SEM1']);
        //console.log(lecs);
        //}
    function ProcessLecs(lecs){
        
        var culmStr = '';
        //process lecs
        for(var i = 0; i < lecs.length; ++i){
            console.log(lecs[i]);
        }
        
        console.log(lecs);
    }		  

        

    //output array of class lecture based on class input names
    function GetClassLectures(ClassNames){
        //Create URL to access lectures from timetable
        var urlBase = 'https://browser.ted.is.ed.ac.uk/generate?';
        urlBase = urlBase + 'courses=';
        
        //Add courses to url
        for(var i = 0; i < ClassNames.length; ++i){
            urlBase += ClassNames[i] + (i < ClassNames.length - 1? ',' : '');
        }
        //Add period and format
        urlBase += '&period=YR&format=json';
        
        
        //2D array on lectures, first dimension = lecture names, 2nd dimension = lecture data
        // lecture data = 'week list', 'location', 'day of week'
        var lectureData = [];
        
        //Get data from URL
        $.getJSON(urlBase, function(data){
            //console.log(JSON.stringify( data, null, 2 ) );
            //console.log(data.status);
            //console.log(data[0]['name']);
            for(var i = 0; i < data.length; ++i){
                //search through the names of all courses
                var name = data[i]['name'];
                //find the names that only contain 'Lecture' keyword
                if(name.indexOf('Lecture') > -1){
                    //console.log(data[i]);
                    lectureData.push(data[i]['name']);
                    
                    //var lastIndx = lectureData.length - 1;
                    
                    //lectureData.push(data[i]['week_label']);
                    //console.log(data[i]['week_label']);
                    lectureData.push(data[i]['location'][0]['building'] + ', ' + data[i]['location'][0]['room']);
                    //console.log(data[i]['location'][0]['building'] + ', ' + data[i]['location'][0]['room']);
                    lectureData.push(data[i]['day_verbose']);
                    
                    lectureData.push(data[i]['start']);
                    
                    lectureData.push(data[i]['end']);
                    //console.log(data[i]['day_verbose']);
                }
            }
            
            ProcessLecs(lectureData);
        });
        
        /*if(lectureData.length != 0)
            console.log(lectureData);
        //display lec data
        for(var l = 0; l < lectureData.length; ++l){
            console.log(lectureData[l]);
            /*for(var d = 0; d < lectureData[l].length; ++d){
                console('   ' + lectureData[l][d]);
            }*/
        //}
    } 